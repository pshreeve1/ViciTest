.. _media:

Media
#####

ViciBox supports installation from a USB flash drive as well as a CD/DVD drive. This is accomplished through a hybrid ISO file that can be used for either media type. A simple ISO to USB writer like ImageUSB or Rufus can be used to create the installation thumb drive. There are two different installation medias currently available for ViciBox.

.. toctree::
   :maxdepth: 2
   :titlesonly:

   media/media-std
   media/media-md
   media/media-usb
