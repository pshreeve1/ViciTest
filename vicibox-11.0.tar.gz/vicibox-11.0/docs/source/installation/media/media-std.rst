.. _media-std:

Standard ISO
************
:download:`Standard Installation Image <https://download.vicidial.com/iso/vicibox/server/ViciBox_v11.x86_64-11.0.1.iso>`
    The 'standard' version is for installation into a system with a single drive. If you have a hardware RAID card then this is the image to use. When in doubt this is likely the easiest option to install.

