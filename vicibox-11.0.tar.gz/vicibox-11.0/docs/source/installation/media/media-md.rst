.. _media-md:

MultiDevice ISO
***************
:download:`MD RAID1 Installation Image <https://download.vicidial.com/iso/vicibox/server/ViciBox_v11.x86_64-11.0.1-md.iso>`
    The 'MD' or MultiDevice media installs in a software RAID-1. This allows two drives to be used together for failure redundancy. For best results the two drives should be a matched pair. If one drive is slightly smaller it should be installed as the first drive in the system. The smaller drive also needs to be the selected target drive during the Phase 1 installation.