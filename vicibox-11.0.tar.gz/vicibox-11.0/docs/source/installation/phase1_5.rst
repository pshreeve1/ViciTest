.. _phase1_5:

Phase 1.5
#########
   Before ViciDial is installed and setup on the servers it is necessary to configure the network. Since this is a convenient stopping point it is also a good time to do other things like install updates. It's recommended to do both of these where possible

.. toctree::
   :maxdepth: 2
   :titlesonly:

   phase1_5/static-ip
   phase1_5/install-updates
   phase1_5/mdraid-setup