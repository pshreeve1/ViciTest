***********
Maintenance
***********
    Common maintenance items on ViciBox

.. toctree::
   :maxdepth: 2
   :titlesonly:

   maintenance/change-timezone
   maintenance/change-rootpw
   maintenance/externalip