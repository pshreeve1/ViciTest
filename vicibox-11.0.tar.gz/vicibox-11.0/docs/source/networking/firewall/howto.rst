How-To's
********
    How to do weird networking things, to be filled out later.